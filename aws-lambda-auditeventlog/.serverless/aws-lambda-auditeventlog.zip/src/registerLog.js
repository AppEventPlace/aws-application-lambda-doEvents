const AWS = require('aws-sdk');
const dynamoDb = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { rquid, action, requestBody, responseBody, statusCode } = JSON.parse(event.body);

    if (!rquid || !action) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: "rquid y action son campos obligatorios." })
        };
    }

    // Generar timestamp actual
    const timestamp = Date.now();

    // Crear los parámetros para insertar en la tabla de logs
    const logParams = {
        TableName: 'LogEvents',
        Item: {
            rquid: rquid,
            timestamp: timestamp,
            action: action,
            requestBody: requestBody || {},
            responseBody: responseBody || {},
            statusCode: statusCode || 200
        }
    };

    try {
        // Insertar el log en DynamoDB
        await dynamoDb.put(logParams).promise();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Log registrado exitosamente." })
        };
    } catch (error) {
        console.error('Error al registrar el log:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error al registrar el log.", error: error.message })
        };
    }
};
